<?xml version="1.0"encoding="UTF-8"?>
<project version="4">
<component name="AndroidConfiguredLogFilters">
<filters>
<filter>
<option name="logLevel"value="verbose"/>
<option name="logMessagePattern"value=""/>
<option name="logTagPattern"value="LifeCycle"/>
<option name="name"value="LifeCycle"/>
<option name="packageNamePattern"value=""/>
<option name="pid"value=""/>
</filter>
</filters>
</component>
<component name="AndroidLayouts">
<shared>
<config /