package com.langcorrect.android.executive.main;

public class LCExcutive {
    private HomeExecutive homeExecutive;

    public HomeExecutive getHomeExecutive() {
        return homeExecutive;
    }

    public void setHomeExecutive(HomeExecutive homeExecutive) {
        this.homeExecutive = homeExecutive;
    }
}
