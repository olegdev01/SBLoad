package com.langcorrect.android.model.message;

import com.langcorrect.android.model.account.User;

public class LCMessageContact {
    private int contactId;

    private User user;

    private String lastTime;

    private String lastMessage;

    public LCMessageContact(int contactId, User user, String lastTime, String lastMessage) {
        this.contactId = contactId;
        this.user = new User();
        this.user.copy(user);
        this.lastTime = lastTime;
        this.lastMessage = lastMessage;
    }

    public void copy(LCMessageContact contact) {
        if (contact == null) {
            return;
        }

        this.contactId = contact.getContactId();
        this.user.copy(contact.getUser());
        this.lastTime = contact.getLastTime();
        this.lastMessage = contact.getLastMessage();
    }

    public int getContactId() {
        return contactId;
    }

    public void setContactId(int contactId) {
        this.contactId = contactId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getLastTime() {
        return lastTime;
    }

    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }
}
