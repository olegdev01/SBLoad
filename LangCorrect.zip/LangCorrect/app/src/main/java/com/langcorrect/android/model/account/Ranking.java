package com.langcorrect.android.model.account;

public class Ranking {
    private RankingType rankingType;
    private int ranking;
    private User user;
    private int count;

    public Ranking() {

    }

    public Ranking(int ranking, String name, int count) {
        this.ranking = ranking;
        this.user = new User();
        this.user.setUserName(name);
        this.count = count;
    }

    public void copy(Ranking newRanking) {
        this.ranking = newRanking.getRanking();
        this.user = new User();
        this.user.copy(newRanking.getUser());
        this.count = newRanking.getCount();
    }

    public RankingType getRankingType() {
        return rankingType;
    }

    public void setRankingType(RankingType rankingType) {
        this.rankingType = rankingType;
    }

    public int getRanking() {
        return ranking;
    }

    public void setRanking(int ranking) {
        this.ranking = ranking;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
