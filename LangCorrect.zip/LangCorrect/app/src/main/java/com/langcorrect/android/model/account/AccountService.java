package com.langcorrect.android.model.account;

import com.langcorrect.android.model.CommonResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface AccountService {

    @FormUrlEncoded
    @POST("customer/forget_password.do")
    Call<CommonResponse> forgot(@Field("email") String userName);

    @FormUrlEncoded
    @POST("customer/sign_up.do")
    Call<CommonResponse> signUp(@Field("username") String userName,
                                @Field("password") String password,
                                @Field("email_address") String email,
                                @Field("phone_number") String phone,
                                @Field("is_mobile") Integer isMobile,
                                @Field("is_phone") Integer isPhone);

    @FormUrlEncoded
    @POST("customer/resend_activation.do")
    Call<CommonResponse> resendActivation(@Field("username") String userName,
                                          @Field("is_phone") Integer isPhone);

    @FormUrlEncoded
    @POST("customer/activate_user.do")
    Call<CommonResponse> activate(@Field("username") String userName,
                                  @Field("password") String password,
                                  @Field("activation_code") String activationCode,
                                  @Field("is_mobile") Integer isMobile);
}
