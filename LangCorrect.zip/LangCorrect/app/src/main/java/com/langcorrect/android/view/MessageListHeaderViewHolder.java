package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;

class MessageListHeaderViewHolder extends RecyclerView.ViewHolder {

    final AppCompatTextView headerTextView;

    MessageListHeaderViewHolder(@NonNull View view) {
        super(view);

        headerTextView = view.findViewById(R.id.txt_category);
    }
}
