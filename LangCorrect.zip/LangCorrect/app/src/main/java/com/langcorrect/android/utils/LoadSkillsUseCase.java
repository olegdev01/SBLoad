package com.langcorrect.android.utils;

import android.content.Context;

import androidx.annotation.NonNull;

import com.langcorrect.android.common.Constants;
import com.langcorrect.android.model.lang.Skill;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class LoadSkillsUseCase {

    public Map<String, List<Skill>> execute(@NonNull final Context context) {
        final Map<String, List<Skill>> map = new LinkedHashMap<>();

        ArrayList<String> categories = new ArrayList<String>() {
            {
                add("Beginner");
                add("Intermediate");
                add("Advanced");
            }
        };

        for (String category : categories) {
            final List<Skill> filteredSkills = getSkillsWithCategory(
                    Constants.skills,
                    category
            );

            if (filteredSkills.size() > 0) {
                map.put(String.valueOf(category), filteredSkills);
            }
        }

        return map;
    }

    private List<Skill> getSkillsWithCategory(@NonNull final ArrayList<Skill> skills, final String cateory) {
        final List<Skill> skillsList = new ArrayList<>();

        for (final Skill skill : skills) {
            if (skill.getSkillCategory().equals(cateory)) {
                skillsList.add(new Skill(skill.getSkillCategory(), skill.getSkillName(), skill.getSkillDescription(), skill.getLevel()));
            }
        }

        return skillsList;
    }
}
