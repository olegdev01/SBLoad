package com.langcorrect.android.model.lang;

import com.langcorrect.android.model.account.User;

public class LCEntry {
    private User user;
    private String dateTime;
    private String title;
    private String content;
    private Integer correlationCount;
    private Integer commentCount;
    private Integer visitCount;

    public LCEntry() {
        this.user = new User("1", "Username", true, 12);
        this.dateTime = "";
        this.title = "";
        this.content = "";
        this.correlationCount = 5;
        this.commentCount = 7;
        this.visitCount = 45;
    }

    public LCEntry(User user, String dateTime, String title, String content) {
        this.user = user;
        this.dateTime = dateTime;
        this.title = title;
        this.content = content;
    }

    public LCEntry(String dateTime, String title, String content) {
        this.user = new User("1", "Username", true, 12);
        this.dateTime = dateTime;
        this.title = title;
        this.content = content;
        this.correlationCount = 5;
        this.commentCount = 7;
        this.visitCount = 45;
    }

    public void copy(LCEntry entry) {
        if (entry == null) {
            return;
        }

        this.user.copy(entry.getUser());
        this.dateTime = entry.getDateTime();
        this.title = entry.getTitle();
        this.content = entry.getContent();
        this.correlationCount = entry.getCorrelationCount();
        this.commentCount = entry.getCommentCount();
        this.visitCount = entry.getVisitCount();
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getCorrelationCount() {
        return correlationCount;
    }

    public void setCorrelationCount(Integer correlationCount) {
        this.correlationCount = correlationCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }
}
