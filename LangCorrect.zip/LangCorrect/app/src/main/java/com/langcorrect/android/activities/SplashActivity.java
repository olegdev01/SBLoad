package com.langcorrect.android.activities;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;

import com.langcorrect.android.R;

public class SplashActivity extends BaseActivity {

    private ImageView imgMainLogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        imgMainLogo = findViewById(R.id.imgMainLogo);
        imgMainLogo.setVisibility(View.INVISIBLE);

        startLogoAnimation();
    }

    private void startLogoAnimation() {
        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1500);
        imgMainLogo.startAnimation(anim);
        imgMainLogo.postDelayed(() -> {
            imgMainLogo.setVisibility(View.VISIBLE);
            new Handler().postDelayed(this::goToOnBoardingActivity, 500);
        }, 1500);
    }

    private void goToOnBoardingActivity() {
        showActivity(HomeActivity.class, ANIMATION_RIGHT_TO_LEFT, true);
    }
}
