package com.langcorrect.android.model.account;

public enum RankingType {
    STREAK("Highest Streak"),
    JOURNALS("Most Journals"),
    CORRECTIONS("Most Corrections");

    public final String rawValue;

    RankingType(String rawValue) {
        this.rawValue = rawValue;
    }
}
