package com.langcorrect.android.common;

import com.langcorrect.android.model.lang.Language;
import com.langcorrect.android.model.lang.Skill;

import java.util.ArrayList;

public interface Constants {

    //
    // View transition animation
    //

    int ANIMATION_RIGHT_TO_LEFT = 1;
    int ANIMATION_LEFT_TO_RIGHT = 2;
    int ANIMATION_BOTTOM_TO_UP = 3;
    int ANIMATION_UP_TO_BOTTOM = 4;

    //
    // Language
    //

    String LANG_TYPE_KEY = "lang_type_key";
    int LANG_NATIVE = 1;
    int LANG_STUDY1 = 2;
    int LANG_STUDY2 = 3;
    int REQUEST_SELECT_LANG = 4;

    ArrayList<Language> langs = new ArrayList<Language>() {
        {
            add(new Language(1, "日本语"));
            add(new Language(2, "中国语"));
            add(new Language(123, "Abkhazian"));
            add(new Language(124, "Afar"));
            add(new Language(125, "Afrikaans"));
            add(new Language(126, "Akan"));
            add(new Language(127, "Albanian"));
            add(new Language(128, "Amharic"));
            add(new Language(4, "Arabic"));
            add(new Language(129, "Aragonese"));
            add(new Language(130, "Armenian"));
            add(new Language(131, "Assamese"));
            add(new Language(132, "Avaric"));
            add(new Language(136, "Bambara"));
            add(new Language(137, "Bashkir"));
            add(new Language(138, "Belarusian"));
            add(new Language(139, "Bengali"));
            add(new Language(133, "Bosnian"));
            add(new Language(140, "Breton"));
            add(new Language(101, "Bulgarian"));
            add(new Language(134, "Burmese"));
            add(new Language(14, "Cantonese"));
            add(new Language(135, "Catalan"));
            add(new Language(170, "Central Khmer"));
            add(new Language(141, "Chechen"));
            add(new Language(142, "Chichewa"));
            add(new Language(205, "Church Slavic"));
            add(new Language(144, "Corsican"));
            add(new Language(143, "Cree"));
            add(new Language(100, "Croatian"));
            add(new Language(102, "Czech"));
            add(new Language(103, "Danish"));
            add(new Language(104, "Dutch"));
            add(new Language(145, "Dzongkha"));
            add(new Language(20, "English"));
            add(new Language(146, "Esperanto"));
            add(new Language(121, "Estonian"));
            add(new Language(147, "Ewe"));
            add(new Language(148, "Faroese"));
            add(new Language(149, "Fijian"));
            add(new Language(105, "Finnish"));
            add(new Language(26, "French"));
            add(new Language(155, "Fulah"));
            add(new Language(222, "Gaelic"));
            add(new Language(150, "Galician"));
            add(new Language(179, "Ganda"));
            add(new Language(120, "Georgian"));
            add(new Language(29, "German"));
            add(new Language(106, "Greek"));
            add(new Language(151, "Guarani"));
            add(new Language(156, "Gujarati"));
            add(new Language(152, "Haitian"));
            add(new Language(157, "Hausa"));
            add(new Language(107, "Hebrew"));
            add(new Language(158, "Herero"));
            add(new Language(122, "Hindi"));
            add(new Language(108, "Hungarian"));
            add(new Language(162, "Icelandic"));
            add(new Language(160, "Igbo"));
            add(new Language(109, "Indonesian"));
            add(new Language(163, "Inuktitut"));
            add(new Language(161, "Inupiaq"));
            add(new Language(159, "Irish"));
            add(new Language(39, "Italian"));
            add(new Language(40, "Japanese"));
            add(new Language(164, "Javanese"));
            add(new Language(165, "Kalaallisut"));
            add(new Language(166, "Kannada"));
            add(new Language(167, "Kanuri"));
            add(new Language(168, "Kashmiri"));
            add(new Language(169, "Kazakh"));
            add(new Language(171, "Kikuyu"));
            add(new Language(172, "Kinyarwanda"));
            add(new Language(173, "Kirghiz"));
            add(new Language(174, "Komi"));
            add(new Language(175, "Kongo"));
            add(new Language(45, "Korean"));
            add(new Language(177, "Kuanyama"));
            add(new Language(176, "Kurdish"));
            add(new Language(182, "Lao"));
            add(new Language(110, "Latin"));
            add(new Language(185, "Latvian"));
            add(new Language(180, "Limburgan"));
            add(new Language(181, "Lingala"));
            add(new Language(183, "Lithuanian"));
            add(new Language(184, "Luba-Katanga"));
            add(new Language(178, "Luxembourgish"));
            add(new Language(187, "Macedonian"));
            add(new Language(188, "Malagasy"));
            add(new Language(111, "Malay"));
            add(new Language(189, "Malayalam"));
            add(new Language(190, "Maltese"));
            add(new Language(56, "Mandarin"));
            add(new Language(186, "Manx"));
            add(new Language(191, "Maori"));
            add(new Language(192, "Marathi"));
            add(new Language(193, "Marshallese"));
            add(new Language(112, "Mongolian"));
            add(new Language(194, "Nauru"));
            add(new Language(195, "Navajo"));
            add(new Language(198, "Ndonga"));
            add(new Language(197, "Nepali"));
            add(new Language(196, "North Ndebele"));
            add(new Language(219, "Northern Sami"));
            add(new Language(113, "Norwegian"));
            add(new Language(199, "Norwegian Bokmål"));
            add(new Language(200, "Norwegian Nynorsk"));
            add(new Language(203, "Occitan"));
            add(new Language(204, "Ojibwa"));
            add(new Language(207, "Oriya"));
            add(new Language(206, "Oromo"));
            add(new Language(208, "Ossetian"));
            add(new Language(210, "Pali"));
            add(new Language(212, "Pashto"));
            add(new Language(211, "Persian"));
            add(new Language(257, "Phoenician"));
            add(new Language(114, "Polish"));
            add(new Language(68, "Portuguese"));
            add(new Language(209, "Punjabi"));
            add(new Language(213, "Quechua"));
            add(new Language(115, "Romanian"));
            add(new Language(214, "Romansh"));
            add(new Language(215, "Rundi"));
            add(new Language(72, "Russian"));
            add(new Language(220, "Samoan"));
            add(new Language(221, "Sango"));
            add(new Language(216, "Sanskrit"));
            add(new Language(217, "Sardinian"));
            add(new Language(116, "Serbian"));
            add(new Language(223, "Shona"));
            add(new Language(201, "Sichuan Yi"));
            add(new Language(218, "Sindhi"));
            add(new Language(224, "Sinhala"));
            add(new Language(225, "Slovak"));
            add(new Language(259, "Slovenian"));
            add(new Language(226, "Somali"));
            add(new Language(202, "South Ndebele"));
            add(new Language(227, "Southern Sotho"));
            add(new Language(79, "Spanish"));
            add(new Language(228, "Sundanese"));
            add(new Language(229, "Swahili"));
            add(new Language(230, "Swati"));
            add(new Language(117, "Swedish"));
            add(new Language(237, "Tagalog"));
            add(new Language(243, "Tahitian"));
            add(new Language(233, "Tajik"));
            add(new Language(231, "Tamil"));
            add(new Language(241, "Tatar"));
            add(new Language(232, "Telugu"));
            add(new Language(85, "Thai"));
            add(new Language(235, "Tibetan"));
            add(new Language(234, "Tigrinya"));
            add(new Language(258, "Tok Pisin"));
            add(new Language(239, "Tonga"));
            add(new Language(88, "Traditional Chinese"));
            add(new Language(240, "Tsonga"));
            add(new Language(238, "Tswana"));
            add(new Language(118, "Turkish"));
            add(new Language(236, "Turkmen"));
            add(new Language(242, "Twi"));
            add(new Language(244, "Uighur"));
            add(new Language(119, "Ukranian"));
            add(new Language(245, "Urdu"));
            add(new Language(246, "Uzbek"));
            add(new Language(247, "Venda"));
            add(new Language(96, "Vietnamese"));
            add(new Language(248, "Volapük"));
            add(new Language(249, "Walloon"));
            add(new Language(153, "Welsh"));
            add(new Language(251, "Western Frisian"));
            add(new Language(250, "Wolof"));
            add(new Language(252, "Xhosa"));
            add(new Language(253, "Yiddish"));
            add(new Language(254, "Yoruba"));
            add(new Language(255, "Zhuang"));
            add(new Language(256, "Zulu"));
        }
    };

    ArrayList<Skill> skills = new ArrayList<Skill>() {
        {
            add(new Skill("Beginner", "Beginner (A1)", "Can understand and use familiar everyday expressions and very basic phrases aimed at the satisfaction of needs of a concrete type.", 1));
            add(new Skill("Beginner", "Elementary (A2)", "Can understand sentences and frequently used expressions related to areas of most immediate relevance (e.g. very basic personal and family information, shopping, local geography, employment).", 2));
            add(new Skill("Intermediate", "Intermediate (B1)", "Can converse about day to day topics including those related to work, school, leisure, etc. Can deal with most situations likely to arise whilst travelling in an area where the language is spoken.", 3));
            add(new Skill("Intermediate", "Upper Intermediate (B2)", "Understands the main ideas of complex text on both concrete and abstract topics, including technical discussions in his/her field of specialization.", 4));
            add(new Skill("Advanced", "Advanced (C1)", "Can understand a wide range of demanding, longer texts, and recognize implicit meaning. Can express him/herself fluently and spontaneously without much obvious searching for expressions.", 4.5f));
            add(new Skill("Advanced", "Proficient (C2)", "Understand with ease virtually everything heard or read. Can summarize information from different spoken and written sources and reconstruct arguments and accounts in a coherent presentation.", 5));
        }
    };
}
