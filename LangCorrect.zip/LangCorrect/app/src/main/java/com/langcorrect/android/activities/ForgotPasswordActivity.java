package com.langcorrect.android.activities;

import android.os.Bundle;

import com.langcorrect.android.R;

public class ForgotPasswordActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        initView();
    }

    private void initView() {
        findViewById(R.id.btn_send).setOnClickListener(v -> showError("Reset password link is sent."));
    }
}