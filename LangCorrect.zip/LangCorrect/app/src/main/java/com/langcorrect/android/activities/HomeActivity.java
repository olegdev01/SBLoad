package com.langcorrect.android.activities;

import android.os.Bundle;
import android.view.View;

import com.langcorrect.android.R;

public class HomeActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initView();
    }

    private void initView() {
        findViewById(R.id.btn_get_started).setOnClickListener(this);
        findViewById(R.id.btn_login).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_get_started:
                showActivity(RegisterActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_login:
                showActivity(LoginActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
        }
    }
}
