package com.langcorrect.android.executive.lang;

import com.langcorrect.android.executive.CommonExecutive;

public class SelectLangExecutive extends CommonExecutive {
    public SelectLangExecutive(SelectLangDisplay display) {
        super(display);
        this.display = display;
    }

    public interface SelectLangDisplay extends CommonExecutive.CommonDisplay {
        void languageSelected();
    }
}