package com.langcorrect.android.view;

import android.app.ProgressDialog;
import android.content.Context;

import com.langcorrect.android.R;

public class WaitingDialog extends ProgressDialog {

    public WaitingDialog(Context context) {
        super(context, R.style.WaitingDialog);

        setMessage(context.getString(R.string.please_wait));
        setCancelable(false);
    }

    public WaitingDialog(Context context, String title, String message) {
        super(context, R.style.WaitingDialog);

        setTitle(title);
        setMessage(message);
        setCancelable(false);
    }

    public WaitingDialog(Context context, String message) {
        super(context, R.style.WaitingDialog);

        setTitle(R.string.please_wait);
        setMessage(message);
        setCancelable(false);
    }
}
