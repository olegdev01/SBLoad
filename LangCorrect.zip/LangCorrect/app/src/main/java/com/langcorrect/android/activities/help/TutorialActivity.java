package com.langcorrect.android.activities.help;

import android.os.Bundle;

import com.langcorrect.android.R;
import com.langcorrect.android.activities.BaseSubActivity;

public class TutorialActivity extends BaseSubActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();
    }
}
