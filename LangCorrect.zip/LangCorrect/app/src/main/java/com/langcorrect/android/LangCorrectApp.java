package com.langcorrect.android;

import android.app.Application;

import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class LangCorrectApp extends Application {
    public static final String DEFAULT_FONT = "fonts/OpenSans-Regular.ttf";
    private static LangCorrectApp instance;

    public static LangCorrectApp getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        //init default font
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath(DEFAULT_FONT)
                .setFontAttrId(R.attr.fontPath)
                .build());
    }
}