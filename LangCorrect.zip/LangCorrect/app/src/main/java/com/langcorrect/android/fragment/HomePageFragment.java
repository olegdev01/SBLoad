package com.langcorrect.android.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.activities.entry.EntryDetailActivity;
import com.langcorrect.android.activities.entry.WriteEntryActivity;
import com.langcorrect.android.common.AppData;
import com.langcorrect.android.executive.main.HomeExecutive;
import com.langcorrect.android.model.lang.LCEntry;
import com.langcorrect.android.model.lang.LCEntryType;
import com.langcorrect.android.view.EntryAdapter;
import com.langcorrect.android.view.SwipeRefreshLayout;

import java.util.ArrayList;

public class HomePageFragment extends BaseFragment implements HomeExecutive.HomePageDisplay, EntryAdapter.AdapterListener {

    final String TAG = HomePageFragment.class.getSimpleName();
    View spaceView;
    private LCEntryType entryType;
    private String pageTitle;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private EntryAdapter adapter;
    private boolean isLoading;
    private int pastVisibleItems, visibleItemCount, totalItemCount;
    private HomeExecutive executive;

    public HomePageFragment() {
        isLoading = false;

        entryType = LCEntryType.ALL;
        pageTitle = "";
    }

    public static HomePageFragment newInstance(Object... args) {
        HomePageFragment fragment = new HomePageFragment();

        if (args != null && args.length > 0) {
            fragment.entryType = (LCEntryType) args[0];
        }

        if (args != null && args.length > 1) {
            fragment.pageTitle = (String) args[1];
        }

        return fragment;
    }

    @Override
    public String getFragmentTag() {
        return HomePageFragment.class.getSimpleName();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);
        if (bridge == null) {
            return root;
        }

        View contentView = inflater.inflate(R.layout.fragment_home_page, container, false);

        recyclerView = contentView.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        spaceView = contentView.findViewById(R.id.layout_space);

        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new EntryAdapter(this, getActivity());
        recyclerView.setAdapter(adapter);

//        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
//            @Override
//            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
//                if (dy > 0) {
//                    visibleItemCount = layoutManager.getChildCount();
//                    totalItemCount = layoutManager.getItemCount();
//                    pastVisibleItems = layoutManager.findFirstVisibleItemPosition();
//
//                    if (visibleItemCount + pastVisibleItems >= totalItemCount) {
//                        if (!isLoading) {
//                            isLoading = true;
//                            Log.d(TAG, "Last Item Wow!");
//
//                            swipeRefreshLayout.setRefreshing(true);
//                            executive.loadPageAndAppend(entryType);
//                        }
//
//                        spaceView.setVisibility(View.VISIBLE);
//                    } else {
//                        spaceView.setVisibility(View.GONE);
//                    }
//                } else {
//                    spaceView.setVisibility(View.GONE);
//                }
//            }
//        });

//        swipeRefreshLayout = contentView.findViewById(R.id.swipe_layout);
//        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                swipeRefreshLayout.setRefreshing(true);
//
//                executive.reloadPage(entryType);
//            }
//        });

        return contentView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {
            return;
        }

        executive = AppData.lcExcutive.getHomeExecutive();
        executive.loadPageDisplay(entryType, this);
    }

    public String getTitle() {
        return pageTitle;
    }

    @UiThread
    @Override
    public void reloadPage(ArrayList<LCEntry> entries) {
        adapter.setEntryItems(entries);
        adapter.notifyDataSetChanged();
    }

    //
    // Adapter Listener
    //

    @UiThread
    @Override
    public void onGear(LCEntry entry, Integer position, Integer gearPosition) {
        if (gearPosition == position) {
            adapter.setGearPosition(-1);
            adapter.notifyItemChanged(gearPosition);
            return;
        }

        adapter.setGearPosition(position);
        if (gearPosition != -1) {
            adapter.notifyItemChanged(gearPosition);
        }
        adapter.notifyItemChanged(position);
    }

    @UiThread
    @Override
    public void onDetail(LCEntry entry, Integer position, Integer gearPosition) {
        if (gearPosition != -1) {
            adapter.setGearPosition(-1);
            adapter.notifyItemChanged(gearPosition);
            return;
        }
        this.bridge.switchTo(EntryDetailActivity.class, null);
    }

    @UiThread
    @Override
    public void onPrompt(LCEntry message, Integer position) {

    }

    @UiThread
    @Override
    public void onEntry(LCEntry message, Integer position) {
        this.bridge.switchTo(WriteEntryActivity.class, null);
    }
}
