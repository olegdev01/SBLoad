package com.langcorrect.android.activities;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.Language;
import com.langcorrect.android.utils.LoadLanguagesUseCase;
import com.langcorrect.android.view.LanguagesSection;

import java.util.List;
import java.util.Map;

import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;

public class LangListActivity extends BaseActivity implements LanguagesSection.ClickListener {

    private RecyclerView languageRecyclerView;
    private SectionedRecyclerViewAdapter sectionedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lang_list);
        initView();
    }

    private void initView() {
        languageRecyclerView = findViewById(R.id.recycler_langs);

        sectionedAdapter = new SectionedRecyclerViewAdapter();

        final Map<String, List<Language>> languagesMap = new LoadLanguagesUseCase().execute(this);
        for (final Map.Entry<String, List<Language>> entry : languagesMap.entrySet()) {
            if (entry.getValue().size() > 0) {
                sectionedAdapter.addSection(new LanguagesSection(entry.getKey(), entry.getValue(), this));
            }
        }

        languageRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        languageRecyclerView.setAdapter(sectionedAdapter);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
    }

    @Override
    public void onItemRootViewClicked(@NonNull String sectionTitle, int itemAdapterPosition) {
        int sectionCount = sectionedAdapter.getSectionCount();
        for (int index = 0; index < sectionCount; index++) {
            LanguagesSection section = (LanguagesSection) sectionedAdapter.getSection(index);
            for (Language language : section.getList()) {
                language.setChecked(false);
            }
        }

        int positionInSection = sectionedAdapter.getPositionInSection(itemAdapterPosition);
        LanguagesSection selectedSection = (LanguagesSection) sectionedAdapter.getSectionForPosition(itemAdapterPosition);

        selectedSection.getList().get(positionInSection).setChecked(true);
        sectionedAdapter.notifyDataSetChanged();

        showActivity(SkillListActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
    }
}
