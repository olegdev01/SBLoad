package com.langcorrect.android.fragment;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresPermission;
import androidx.annotation.UiThread;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.langcorrect.android.R;
import com.langcorrect.android.activities.entry.WriteEntryActivity;
import com.langcorrect.android.activities.message.MessagesActivity;
import com.langcorrect.android.common.AppData;
import com.langcorrect.android.executive.main.HomeExecutive;
import com.langcorrect.android.model.lang.LCEntryType;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment
        extends BaseFragment
        implements HomeExecutive.HomeDisplay {

    final String TAG = HomeFragment.class.getSimpleName();

    TabLayout tabLayout;
    ViewPager viewPager;
    PageAdapter pageAdapter;
    HomeExecutive executive;
    BottomNavigationView bottomNavigationView;

    public static HomeFragment newInstance(Object... args) {
        return new HomeFragment();
    }

    @Override
    public String getFragmentTag() {
        return HomeFragment.class.getCanonicalName();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);
        if (bridge == null) {
            return root;
        }

        //
        // Bind Controls
        //

        View contentView = inflater.inflate(R.layout.fragment_home, container, false);

        pageAdapter = new PageAdapter(getChildFragmentManager());

        viewPager = contentView.findViewById(R.id.view_pager);
        viewPager.setAdapter(pageAdapter);

        tabLayout = contentView.findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);

        bottomNavigationView = contentView.findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.menu_item_add:
                    new AlertDialog.Builder(getActivity())
                            .setItems(R.array.entry_option, (dialogInterface, position) -> {
                                if (position == 1) {
                                    this.bridge.switchTo(WriteEntryActivity.class, null);
                                }
                            })
                            .show();
                    break;
            }
            return false;
        });

        return contentView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {
            return;
        }

        //
        // Load executive
        //

        executive = new HomeExecutive(this);
        AppData.lcExcutive.setHomeExecutive(executive);

        //
        // Load display
        //

        executive.displayDidLoad();
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e("LifeCycle", "HomeFragment onStart");
    }

    @Override
    public void loadDisplay() {
    }

    @UiThread
    @Override
    public void loadPages() {
        pageAdapter.addPage(LCEntryType.ALL, getResources().getString(R.string.tab_all_entries));
        pageAdapter.addPage(LCEntryType.FRIENDS, getResources().getString(R.string.tab_friends));
        pageAdapter.addPage(LCEntryType.OTHER, getResources().getString(R.string.tab_other_learners));
        pageAdapter.notifyDataSetChanged();
    }

    private class PageAdapter extends FragmentPagerAdapter {
        List<HomePageFragment> fragmentsList;

        private PageAdapter(FragmentManager fragmentManager) {
            super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            fragmentsList = new ArrayList<>();
        }

        @Override
        public HomePageFragment getItem(int position) {
            return fragmentsList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentsList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return getItem(position).getTitle();
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        private void addPage(LCEntryType entryType,
                             String title) {

            HomePageFragment fragment = HomePageFragment.newInstance(entryType, title);
            fragmentsList.add(fragment);
        }
    }
}
