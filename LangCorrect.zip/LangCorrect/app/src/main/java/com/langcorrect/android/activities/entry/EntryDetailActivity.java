package com.langcorrect.android.activities.entry;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.langcorrect.android.R;
import com.langcorrect.android.activities.BaseSubActivity;
import com.langcorrect.android.activities.ForgotPasswordActivity;
import com.langcorrect.android.fragment.BaseFragment;
import com.langcorrect.android.fragment.Bridge;
import com.langcorrect.android.fragment.CorrectionPageFragment;
import com.langcorrect.android.model.lang.LCCorrectionType;

import java.util.ArrayList;
import java.util.List;

public class EntryDetailActivity extends BaseSubActivity implements Bridge {
    EntryDetailActivity.PageAdapter pageAdapter;
    ViewPager viewPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry_detail);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();

        pageAdapter = new EntryDetailActivity.PageAdapter(getSupportFragmentManager());

        viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(pageAdapter);

        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(new OnCorrectionTabSelectedListener());

        pageAdapter.addPage(LCCorrectionType.INDIVIDUAL, getResources().getString(R.string.individual_correction));
        pageAdapter.addPage(LCCorrectionType.GROUP, getResources().getString(R.string.grouped_correction));
        pageAdapter.notifyDataSetChanged();
        for (int index = 0; index < tabLayout.getTabCount(); index++) {
            TabLayout.Tab tab = tabLayout.getTabAt(index);
            if (tab != null) {
                LinearLayout tabParentLayout = (LinearLayout) ((ViewGroup) tabLayout.getChildAt(0)).getChildAt(tab.getPosition());
                TextView tabTextView = (TextView) tabParentLayout.getChildAt(1);
                Typeface typeface;
                if (index == 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        tabTextView.setTextAppearance(R.style.SelectedTabLayout);
                    } else {
                        typeface = Typeface.createFromAsset(EntryDetailActivity.this.getAssets(), "fonts/OpenSans-Bold.ttf");
                        tabTextView.setTypeface(typeface, Typeface.NORMAL);
                        tabTextView.setAllCaps(false);
                    }
                } else if (index == 1) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        tabTextView.setTextAppearance(R.style.DeselectedTabLayout);
                    } else {
                        typeface = Typeface.createFromAsset(EntryDetailActivity.this.getAssets(), "fonts/OpenSans-Regular.ttf");
                        tabTextView.setTypeface(typeface, Typeface.NORMAL);
                        tabTextView.setAllCaps(false);
                    }
                }
            }
        }
    }

    @Override
    public void onBack() {

    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, boolean cleanStack) {

    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, int pop) {

    }

    @Override
    public void switchTo(Class activity, Bundle data) {
        if (data == null) {
            showActivity(activity, ANIMATION_RIGHT_TO_LEFT, false);
        } else {
            showActivity(activity, data);
        }
    }

    @Override
    public void switchTo(Class activity, Bundle data, int resultCode) {
    }

    private class OnCorrectionTabSelectedListener implements TabLayout.OnTabSelectedListener {

        @Override
        public void onTabSelected(TabLayout.Tab tab) {
            LinearLayout tabParentLayout = (LinearLayout) ((ViewGroup) tabLayout.getChildAt(0)).getChildAt(tab.getPosition());
            TextView tabTextView = (TextView) tabParentLayout.getChildAt(1);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                tabTextView.setTextAppearance(R.style.SelectedTabLayout);
            } else {
                Typeface typeface = Typeface.createFromAsset(EntryDetailActivity.this.getAssets(), "fonts/OpenSans-Bold.ttf");
                tabTextView.setTypeface(typeface, Typeface.NORMAL);
                tabTextView.setAllCaps(false);
            }
        }

        @Override
        public void onTabUnselected(TabLayout.Tab tab) {
            LinearLayout tabParentLayout = (LinearLayout) ((ViewGroup) tabLayout.getChildAt(0)).getChildAt(tab.getPosition());
            TextView tabTextView = (TextView) tabParentLayout.getChildAt(1);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                tabTextView.setTextAppearance(R.style.DeselectedTabLayout);
            } else {
                Typeface typeface = Typeface.createFromAsset(EntryDetailActivity.this.getAssets(), "fonts/OpenSans-Regular.ttf");
                tabTextView.setTypeface(typeface, Typeface.NORMAL);
                tabTextView.setAllCaps(false);
            }
        }

        @Override
        public void onTabReselected(TabLayout.Tab tab) {

        }
    }

    private class PageAdapter extends FragmentPagerAdapter {
        List<CorrectionPageFragment> fragmentsList;

        private PageAdapter(FragmentManager fragmentManager) {
            super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            fragmentsList = new ArrayList<>();
        }

        @Override
        public CorrectionPageFragment getItem(int position) {
            return fragmentsList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentsList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return getItem(position).getTitle();
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        private void addPage(LCCorrectionType correctionType,
                             String title) {

            CorrectionPageFragment fragment = CorrectionPageFragment.newInstance(correctionType, title);
            fragmentsList.add(fragment);
        }
    }
}
