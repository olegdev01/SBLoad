package com.langcorrect.android.view;

import android.content.Context;
import android.util.AttributeSet;

import androidx.core.content.ContextCompat;

import com.langcorrect.android.R;

public class SwipeRefreshLayout extends androidx.swiperefreshlayout.widget.SwipeRefreshLayout {
    public SwipeRefreshLayout(Context context) {
        super(context);

        init(context);
    }

    public SwipeRefreshLayout(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }

    private void init(Context context) {
        setColorSchemeColors(
                ContextCompat.getColor(context, R.color.colorPrimary),
                ContextCompat.getColor(context, R.color.colorPrimaryDark),
                ContextCompat.getColor(context, R.color.colorPrimaryLight)
        );
    }
}
