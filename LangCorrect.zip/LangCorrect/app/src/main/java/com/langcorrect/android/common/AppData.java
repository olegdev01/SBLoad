package com.langcorrect.android.common;

import com.langcorrect.android.executive.main.LCExcutive;

public class AppData {
    public static LCExcutive lcExcutive;
}
