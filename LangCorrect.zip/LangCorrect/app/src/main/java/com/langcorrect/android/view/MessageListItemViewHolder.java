package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;

public class MessageListItemViewHolder extends RecyclerView.ViewHolder {

    final View rootView;
    final AppCompatTextView nameTextView, timeTextView, contentTextView;

    MessageListItemViewHolder(@NonNull View view) {
        super(view);

        rootView = view;
        nameTextView = view.findViewById(R.id.txt_user_name);
        timeTextView = view.findViewById(R.id.txt_time);
        contentTextView = view.findViewById(R.id.txt_content);
    }
}
