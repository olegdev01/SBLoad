package com.langcorrect.android.model.account;

import com.stfalcon.chatkit.commons.models.IUser;

public class User implements IUser {
    private String userId;

    private String userName;

    private boolean isPremium;

    private Integer stars;

    private String avatar;

    private boolean online;

    public User() {
        this.userId = "";
        this.userName = "";
        this.isPremium = false;
        this.stars = 0;
        this.avatar = "";
        this.online = false;
    }

    public User(String id, String name, String avatar, boolean online) {
        this.userId = id;
        this.userName = name;
        this.avatar = avatar;
        this.online = online;
    }

    public User(String userId, String userName, boolean isPremium, Integer stars) {
        this.userId = userId;
        this.userName = userName;
        this.isPremium = isPremium;
        this.stars = stars;
    }

    public void copy(User user) {
        if (user == null) {
            return;
        }

        this.userId = user.getUserId();
        this.userName = user.getUserName();
        this.isPremium = user.isPremium();
        this.stars = user.getStars();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public boolean isPremium() {
        return isPremium;
    }

    public void setPremium(boolean premium) {
        isPremium = premium;
    }

    public Integer getStars() {
        return stars;
    }

    public void setStars(Integer stars) {
        this.stars = stars;
    }

    public boolean isOnline() {
        return online;
    }

    @Override
    public String getId() {
        return this.userId;
    }

    @Override
    public String getName() {
        return this.userName;
    }

    @Override
    public String getAvatar() {
        return avatar;
    }
}
