package com.langcorrect.android.activities;

import android.os.Bundle;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.langcorrect.android.R;
import com.langcorrect.android.fragment.BaseFragment;
import com.langcorrect.android.fragment.Bridge;
import com.langcorrect.android.fragment.CorrectionPageFragment;
import com.langcorrect.android.fragment.RankingPageFragment;
import com.langcorrect.android.model.account.RankingType;
import com.langcorrect.android.model.lang.LCCorrectionType;

import java.util.ArrayList;
import java.util.List;

public class RankingActivity extends BaseSubActivity implements Bridge {
    RankingActivity.PageAdapter pageAdapter;
    ViewPager viewPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();

        pageAdapter = new RankingActivity.PageAdapter(getSupportFragmentManager());

        viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(pageAdapter);

        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);

        pageAdapter.addPage(RankingType.STREAK, RankingType.STREAK.rawValue);
        pageAdapter.addPage(RankingType.JOURNALS, RankingType.JOURNALS.rawValue);
        pageAdapter.addPage(RankingType.CORRECTIONS, RankingType.CORRECTIONS.rawValue);
        pageAdapter.notifyDataSetChanged();
    }

    @Override
    public void onBack() {
        onBackPressed();
    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, boolean cleanStack) {

    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, int pop) {

    }

    @Override
    public void switchTo(Class activity, Bundle data) {

    }

    @Override
    public void switchTo(Class activity, Bundle data, int resultCode) {

    }

    private class PageAdapter extends FragmentPagerAdapter {
        List<RankingPageFragment> fragmentsList;

        private PageAdapter(FragmentManager fragmentManager) {
            super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
            fragmentsList = new ArrayList<>();
        }

        @Override
        public RankingPageFragment getItem(int position) {
            return fragmentsList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentsList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return getItem(position).getTitle();
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        private void addPage(RankingType rankingType,
                             String title) {

            RankingPageFragment fragment = RankingPageFragment.newInstance(rankingType, title);
            fragmentsList.add(fragment);
        }
    }
}
