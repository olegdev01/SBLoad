package com.langcorrect.android.activities.entry;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.langcorrect.android.R;
import com.langcorrect.android.activities.BaseActivity;
import com.langcorrect.android.activities.FriendsActivity;
import com.langcorrect.android.activities.PremiumActivity;
import com.langcorrect.android.activities.RankingActivity;
import com.langcorrect.android.activities.SettingsActivity;
import com.langcorrect.android.activities.help.AboutActivity;
import com.langcorrect.android.activities.help.HelpActivity;
import com.langcorrect.android.activities.help.TakeTourActivity;
import com.langcorrect.android.activities.message.MessageListActivity;
import com.langcorrect.android.common.AppData;
import com.langcorrect.android.executive.main.LCExcutive;
import com.langcorrect.android.fragment.BaseFragment;
import com.langcorrect.android.fragment.Bridge;
import com.langcorrect.android.fragment.HomeFragment;

public class MainActivity extends BaseActivity implements Bridge, NavigationView.OnNavigationItemSelectedListener {

    final String FIRST_FRAGMENT_TAG = HomeFragment.class.getCanonicalName();
    DrawerLayout drawerLayout;
    Toolbar headerToolbar;
    NavigationView navigationView;
    private LCExcutive executive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        initView();

        executive = new LCExcutive();
        AppData.lcExcutive = executive;
    }

    private void initView() {
        drawerLayout = findViewById(R.id.drawer_layout);
        headerToolbar = findViewById(R.id.toolbar);
        headerToolbar.setNavigationOnClickListener(view -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START);
            } else {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        navigationView = findViewById(R.id.nav_view);
        switchTo(HomeFragment.newInstance(), false, true);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBack() {
        onBackPressed();
    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, boolean cleanStack) {
        if (cleanStack) {
            cleanBackStack();
        }

        try {
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            if (isReplace) {
                fragmentTransaction = fragmentTransaction.replace(R.id.container, fragment, fragment.getFragmentTag());
            } else {
                fragmentTransaction = fragmentTransaction.add(R.id.container, fragment, fragment.getFragmentTag());
            }

            fragmentTransaction = fragmentTransaction.addToBackStack(fragment.getFragmentTag());
            fragmentTransaction.commitAllowingStateLoss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void switchTo(BaseFragment fragment, boolean isReplace, int pop) {
        for (int i = 0; i < pop; i++) {
            try {
                FragmentManager fragmentManager = getSupportFragmentManager();

                String tag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
                if (tag != null && tag.equals(FIRST_FRAGMENT_TAG))
                    break;

                fragmentManager.popBackStack();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        try {
            FragmentTransaction t = getSupportFragmentManager().beginTransaction();
            if (isReplace)
                t = t.replace(R.id.container, fragment, fragment.getFragmentTag());
            else
                t = t.add(R.id.container, fragment, fragment.getFragmentTag());

            t = t.addToBackStack(fragment.getFragmentTag());
            t.commitAllowingStateLoss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void switchTo(Class activity, Bundle data) {
        if (data == null) {
            showActivity(activity, ANIMATION_RIGHT_TO_LEFT, false);
        } else {
            showActivity(activity, data);
        }
    }

    @Override
    public void switchTo(Class activity, Bundle data, int resultCode) {
        if (data == null) {
            showActivity(activity, resultCode);
        } else {
            showActivity(activity, data, resultCode);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        drawerLayout.closeDrawer(GravityCompat.START);
        switch (item.getItemId()) {
            case R.id.mnu_premium:
                showActivity(PremiumActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_messages:
                showActivity(MessageListActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_friends:
                showActivity(FriendsActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_ranking:
                showActivity(RankingActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_night_mode:
                break;
            case R.id.mnu_about:
                showActivity(AboutActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_help:
                showActivity(HelpActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.mnu_setting:
                showActivity(SettingsActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
        }
        return true;
    }
}
