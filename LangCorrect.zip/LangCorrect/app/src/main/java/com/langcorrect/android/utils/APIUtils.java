package com.langcorrect.android.utils;

import com.langcorrect.android.model.account.AccountService;

public class APIUtils {
        //    static final String BASE_URL = "http://208.73.233.211:8080/YLC/";
        static final String BASE_URL = "https://www.yourlocalcall.com:8443/YLC/";

        public static AccountService getAccountService() {
                return RetrofitClient.getClient(BASE_URL).create(AccountService.class);
        }

        public interface APIResponse<T> {
                void onResponse(T response);
        }
}