package com.langcorrect.android.activities.message;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.activities.BaseSubActivity;
import com.langcorrect.android.executive.message.MessageListExecutive;
import com.langcorrect.android.model.message.LCMessageContact;
import com.langcorrect.android.view.MessageListSection;

import java.util.List;
import java.util.Map;

import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;

public class MessageListActivity extends BaseSubActivity implements MessageListExecutive.MessageListDisplay, MessageListSection.ClickListener {
    private RecyclerView skillRecyclerView;
    private SectionedRecyclerViewAdapter sectionedAdapter;
    private MessageListExecutive executive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_list);

        initView();

        executive = new MessageListExecutive(this);
        executive.loadMessagesList();
    }

    @Override
    protected void initView() {
        super.initView();

        skillRecyclerView = findViewById(R.id.recycler_messages);

        sectionedAdapter = new SectionedRecyclerViewAdapter();
    }

    @Override
    public void onDataLoaded(Map<String, List<LCMessageContact>> messagesMap) {
        for (final Map.Entry<String, List<LCMessageContact>> entry : messagesMap.entrySet()) {
            if (entry.getValue().size() > 0) {
                sectionedAdapter.addSection(new MessageListSection(entry.getKey(), entry.getValue(), this));
            }
        }

        skillRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        skillRecyclerView.setAdapter(sectionedAdapter);
    }

    @Override
    public void onItemRootViewClicked(@NonNull String sectionTitle, int itemAdapterPosition) {
        showActivity(MessagesActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
    }
}
