package com.langcorrect.android.executive;

import com.langcorrect.android.R;
import com.langcorrect.android.model.CommonResponse;

import retrofit2.Response;

public class CommonExecutive {
    protected CommonDisplay display;

    public CommonExecutive(CommonDisplay display) {
        this.display = display;
    }

    public boolean validateResponse(Response response) {
        if (!response.isSuccessful()) {
            display.showError(R.string.request_failed);
            return false;
        }
        CommonResponse responseBody = ((Response<CommonResponse>) response).body();
        if (responseBody == null ||
                responseBody.getCode() != 0) {
            display.showError(responseBody.getMessage());
            return false;
        }
        return true;
    }

    public interface CommonDisplay {
        void showLoading();

        void hideLoading();

        void showError(String message);

        void showError(int message);
    }
}
