package com.langcorrect.android.activities;

import android.os.Bundle;

import com.langcorrect.android.R;

public class FriendsActivity extends BaseSubActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();
    }
}
