package com.langcorrect.android.activities;

import android.os.Bundle;

import com.langcorrect.android.R;

public class PremiumActivity extends BaseSubActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_premium);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();
    }
}
