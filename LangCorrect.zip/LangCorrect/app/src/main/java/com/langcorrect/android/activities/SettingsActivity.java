package com.langcorrect.android.activities;

import android.os.Bundle;

import com.langcorrect.android.R;

public class SettingsActivity extends BaseSubActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();
    }
}
