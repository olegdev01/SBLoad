package com.langcorrect.android.executive.message;

import com.langcorrect.android.executive.CommonExecutive;
import com.langcorrect.android.model.account.User;
import com.langcorrect.android.model.message.LCMessageContact;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MessageListExecutive extends CommonExecutive {
    private MessageListDisplay display;

    public MessageListExecutive(MessageListDisplay display) {
        super(display);
        this.display = display;
    }

    public void loadMessagesList() {
        final Map<String, List<LCMessageContact>> map = new LinkedHashMap<>();

        ArrayList<String> categories = new ArrayList<String>() {
            {
                add("NEW MESSAGES(2)");
                add("OLDER MESSAGES");
            }
        };

        for (String category : categories) {
            List<LCMessageContact> filteredSkills = new ArrayList<>();
            if (category.equals("NEW MESSAGES(2)")) {
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "Masumune", false, 5), "3:42 PM",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "CroatCode", false, 5), "7:09 PM",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
            } else {
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "Dmaster35", false, 5), "4/06/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "Baller377", false, 5), "3/31/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "SynthMage", false, 5), "3/23/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "CheddarShredder", false, 5), "3/11/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "Dmaster35", false, 5), "4/06/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "Baller377", false, 5), "3/31/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "SynthMage", false, 5), "3/23/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
                filteredSkills.add(new LCMessageContact(0, new User("0",
                        "CheddarShredder", false, 5), "3/11/20",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam posuere, sem non laoreet malesuada, diam ex... "));
            }

            if (filteredSkills.size() > 0) {
                map.put(category, filteredSkills);
            }
        }

        display.onDataLoaded(map);
    }

    public interface MessageListDisplay extends CommonDisplay {
        void onDataLoaded(Map<String, List<LCMessageContact>> messagesMap);
    }
}
