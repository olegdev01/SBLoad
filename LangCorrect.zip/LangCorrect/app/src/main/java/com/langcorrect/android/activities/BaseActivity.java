package com.langcorrect.android.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.langcorrect.android.R;
import com.langcorrect.android.common.Constants;
import com.langcorrect.android.custom.LoadingDialog;
import com.langcorrect.android.executive.CommonExecutive.CommonDisplay;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class BaseActivity extends AppCompatActivity implements Constants, CommonDisplay {

    LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void showActivity(Class t) {
        showActivity(t, null);
    }

    public void showActivity(Class activity, Bundle data, int animation, boolean finish) {
        try {
            Intent intent = new Intent(this, activity);
            if (data != null) {
                intent.putExtras(data);
            }
            startActivity(intent);

            switch (animation) {
                case Constants.ANIMATION_RIGHT_TO_LEFT:
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    break;

                case Constants.ANIMATION_LEFT_TO_RIGHT:
                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    break;

                case Constants.ANIMATION_BOTTOM_TO_UP:
                    overridePendingTransition(R.anim.push_up_in, R.anim.push_up_out);
                    break;

                case Constants.ANIMATION_UP_TO_BOTTOM:
                    overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
                    break;
            }

            if (finish) {
                finish();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void showActivity(Class t, Bundle data) {
        showActivity(t, data, -1, true);
    }

    public void showActivity(Class t, int requestCode) {
        showActivity(t, null, requestCode);
    }

    public void showActivity(Class t, Bundle data, int requestCode) {
        Intent intent = new Intent(this, t);
        if (data != null) {
            intent.putExtras(data);
        }
        startActivityForResult(intent, requestCode);
    }

    public void showActivity(Class activity, int animation, boolean finish) {
        try {
            Intent intent = new Intent(this, activity);
            startActivity(intent);

            switch (animation) {
                case Constants.ANIMATION_RIGHT_TO_LEFT:
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    break;

                case Constants.ANIMATION_LEFT_TO_RIGHT:
                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    break;

                case Constants.ANIMATION_BOTTOM_TO_UP:
                    overridePendingTransition(R.anim.push_up_in, R.anim.push_up_out);
                    break;

                case Constants.ANIMATION_UP_TO_BOTTOM:
                    overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
                    break;
            }

            if (finish) {
                finish();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void showActivityForResult(Class activity, String extraDataKey, int extraData, int requestCode) {
        Intent newIntent = new Intent(this, activity);
        newIntent.putExtra(extraDataKey, extraData);
        startActivityForResult(newIntent, requestCode);
    }

    public void showActivityAndClearStack(Class activity, int animation) {
        Intent newIntent = new Intent(this, activity);
        newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        switch (animation) {
            case Constants.ANIMATION_RIGHT_TO_LEFT:
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                break;

            case Constants.ANIMATION_LEFT_TO_RIGHT:
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                break;

            case Constants.ANIMATION_BOTTOM_TO_UP:
                overridePendingTransition(R.anim.push_up_in, R.anim.push_up_out);
                break;

            case Constants.ANIMATION_UP_TO_BOTTOM:
                overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
                break;
        }

        startActivity(newIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (loadingDialog != null) {
            loadingDialog.show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (loadingDialog != null) {
            loadingDialog.dismiss();
        }
    }

    @Override
    public void showLoading() {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
            loadingDialog = null;
        }

        loadingDialog = new LoadingDialog(this, getResources().getString(R.string.loading));
        loadingDialog.show();
    }

    @Override
    public void hideLoading() {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
            loadingDialog = null;
        }
    }

    @Override
    public void showError(String message) {
        try {
            Toast.makeText(this.getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void showError(int message) {
        try {
            Toast.makeText(this.getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    public void cleanBackStack() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
            fragmentManager.popBackStack();
        }
    }
}