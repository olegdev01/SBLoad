package com.langcorrect.android.utils;

import android.content.Context;

import androidx.annotation.NonNull;

import com.langcorrect.android.common.Constants;
import com.langcorrect.android.model.lang.Language;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class LoadLanguagesUseCase {

    public Map<String, List<Language>> execute(@NonNull final Context context) {
        final Map<String, List<Language>> map = new LinkedHashMap<>();

        map.put("#", getLanguagesWithNonLetter(Constants.langs));
        for (char letter = 'A'; letter <= 'Z'; letter++) {
            final List<Language> filteredLanguages = getLanguagesWithLetter(
                    Constants.langs,
                    letter
            );

            if (filteredLanguages.size() > 0) {
                map.put(String.valueOf(letter), filteredLanguages);
            }
        }

        return map;
    }

    private List<Language> getLanguagesWithLetter(@NonNull final ArrayList<Language> languages, final char letter) {
        final List<Language> languagesList = new ArrayList<>();

        for (final Language language : languages) {
            if (language.getName().charAt(0) == letter) {
                languagesList.add(new Language(language.getLangId(), language.getName()));
            }
        }

        return languagesList;
    }

    private List<Language> getLanguagesWithNonLetter(@NonNull final ArrayList<Language> languages) {
        final List<Language> languagesList = new ArrayList<>();
        for (final Language language : languages) {
            boolean hasLetter = false;
            for (char letter = 'A'; letter <= 'Z'; letter++) {
                if (language.getName().charAt(0) == letter) {
                    hasLetter = true;
                    break;
                }
            }

            if (!hasLetter) {
                languagesList.add(new Language(language.getLangId(), language.getName()));
            }
        }

        return languagesList;
    }
}
