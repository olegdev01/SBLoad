package com.langcorrect.android.activities.help;

import android.os.Bundle;
import android.view.View;

import com.langcorrect.android.R;
import com.langcorrect.android.activities.BaseSubActivity;

public class AboutActivity extends BaseSubActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        findViewById(R.id.btn_community_guidelines).setOnClickListener(this);
        findViewById(R.id.btn_dev_credits).setOnClickListener(this);
        findViewById(R.id.btn_change_log).setOnClickListener(this);
        findViewById(R.id.btn_tutorial).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_community_guidelines:
                showActivity(CommunityGuideLinesActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_dev_credits:
                showActivity(DevCreditsActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_change_log:
                showActivity(ChangeLogActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_tutorial:
                showActivity(TutorialActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
        }
    }
}
