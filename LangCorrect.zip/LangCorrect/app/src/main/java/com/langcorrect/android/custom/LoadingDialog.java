package com.langcorrect.android.custom;

import android.app.ProgressDialog;
import android.content.Context;

import com.langcorrect.android.R;

public class LoadingDialog extends ProgressDialog {
    private Context context;
    private String message;

    public LoadingDialog(Context context, String message) {
        super(context, R.style.TransparentProgressDialog);

        this.context = context;
        this.message = message;

        setCancelable(false);
        setMessage(message);
    }
}
