package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.message.LCMessageContact;

import java.util.List;

import io.github.luizgrp.sectionedrecyclerviewadapter.Section;
import io.github.luizgrp.sectionedrecyclerviewadapter.SectionParameters;

public class MessageListSection extends Section {

    private final String title;
    private final List<LCMessageContact> list;
    private final ClickListener clickListener;

    public MessageListSection(@NonNull final String title, @NonNull final List<LCMessageContact> list,
                              @NonNull final ClickListener clickListener) {

        super(SectionParameters.builder()
                .itemResourceId(R.layout.adapter_message_list)
                .headerResourceId(R.layout.adapter_message_list_header)
                .build());

        this.title = title;
        this.list = list;
        this.clickListener = clickListener;
    }

    @Override
    public int getContentItemsTotal() {
        return list.size();
    }

    @Override
    public RecyclerView.ViewHolder getItemViewHolder(final View view) {
        return new MessageListItemViewHolder(view);
    }

    @Override
    public void onBindItemViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final MessageListItemViewHolder itemHolder = (MessageListItemViewHolder) holder;

        final LCMessageContact contact = list.get(position);

        itemHolder.nameTextView.setText(contact.getUser().getUserName());
        itemHolder.timeTextView.setText(contact.getLastTime());
        itemHolder.contentTextView.setText(contact.getLastMessage());

        itemHolder.rootView.setOnClickListener(v ->
                clickListener.onItemRootViewClicked(title, itemHolder.getAdapterPosition())
        );
    }

    @Override
    public RecyclerView.ViewHolder getHeaderViewHolder(final View view) {
        return new MessageListHeaderViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final RecyclerView.ViewHolder holder) {
        final MessageListHeaderViewHolder headerHolder = (MessageListHeaderViewHolder) holder;

        headerHolder.headerTextView.setText(title);
    }

    public String getTitle() {
        return title;
    }

    public List<LCMessageContact> getList() {
        return list;
    }

    public interface ClickListener {

        void onItemRootViewClicked(@NonNull final String sectionTitle, final int itemAdapterPosition);
    }
}