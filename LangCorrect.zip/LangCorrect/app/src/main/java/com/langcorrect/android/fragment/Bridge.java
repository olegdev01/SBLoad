package com.langcorrect.android.fragment;

import android.os.Bundle;

public interface Bridge {
    void onBack();

    void switchTo(BaseFragment fragment, boolean isReplace, boolean cleanStack);

    void switchTo(BaseFragment fragment, boolean isReplace, int pop);

    void switchTo(Class activity, Bundle data);

    void switchTo(Class activity, Bundle data, int resultCode);
}
