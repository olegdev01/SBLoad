package com.langcorrect.android.activities;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.Skill;
import com.langcorrect.android.utils.LoadSkillsUseCase;
import com.langcorrect.android.view.SkillsSection;

import java.util.List;
import java.util.Map;

import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;

public class SkillListActivity extends BaseActivity implements SkillsSection.ClickListener {

    private RecyclerView skillRecyclerView;
    private SectionedRecyclerViewAdapter sectionedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skill_list);
        initView();
    }

    private void initView() {
        skillRecyclerView = findViewById(R.id.recycler_skills);

        sectionedAdapter = new SectionedRecyclerViewAdapter();

        final Map<String, List<Skill>> skillsMap = new LoadSkillsUseCase().execute(this);
        for (final Map.Entry<String, List<Skill>> entry : skillsMap.entrySet()) {
            if (entry.getValue().size() > 0) {
                sectionedAdapter.addSection(new SkillsSection(entry.getKey(), entry.getValue(), this));
            }
        }

        skillRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        skillRecyclerView.setAdapter(sectionedAdapter);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
    }

    @Override
    public void onItemRootViewClicked(@NonNull String sectionTitle, int itemAdapterPosition) {
        int sectionCount = sectionedAdapter.getSectionCount();
        for (int index = 0; index < sectionCount; index++) {
            SkillsSection section = (SkillsSection) sectionedAdapter.getSection(index);
            for (Skill skill : section.getList()) {
                skill.setChecked(false);
            }
        }

        int positionInSection = sectionedAdapter.getPositionInSection(itemAdapterPosition);
        SkillsSection selectedSection = (SkillsSection) sectionedAdapter.getSectionForPosition(itemAdapterPosition);

        selectedSection.getList().get(positionInSection).setChecked(true);
        sectionedAdapter.notifyDataSetChanged();

        finish();
    }
}