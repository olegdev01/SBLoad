package com.langcorrect.android.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import com.langcorrect.android.executive.CommonExecutive;
import com.langcorrect.android.view.WaitingDialog;


public abstract class BaseFragment extends Fragment implements CommonExecutive.CommonDisplay {

    public Bridge bridge;
    public WaitingDialog waitingDialog;

    public void showLoading(String message) {
        if (waitingDialog != null) {
            if (waitingDialog.isShowing())
                return;
        } else
            waitingDialog = new WaitingDialog(getActivity(), message);

        waitingDialog.show();
    }


    public void showLoading() {
        if (waitingDialog != null) {

            if (waitingDialog.isShowing()) {
                return;
            }
        } else {
            waitingDialog = new WaitingDialog(getActivity());
        }

        waitingDialog.show();
    }

    public void setLoading(@StringRes int message) {
        showLoading();

        waitingDialog.setMessage(getString(message));
    }

    public void hideLoading() {
        if (waitingDialog != null) {
            waitingDialog.dismiss();
        }

        waitingDialog = null;
    }

    public void showMessage(String message) {
        if (message == null || message.length() == 0) {
            return;
        }

        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    public void showMessage(int message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    public void showLongMessage(int message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
    }

    public void showLongMessage(String message) {
        if (message == null || message.length() == 0) {
            return;
        }

        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
    }

    public void showError(int message) {
        showLongMessage(message);
    }

    public void showError(String message) {
        showLongMessage(message);
    }

    public void hideKeyboard() {
        Context ctx = getActivity();
        InputMethodManager inputManager = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);

        // check if no view has focus:
        View v = ((Activity) ctx).getCurrentFocus();
        if (v == null) {
            return;
        }

        try {
            inputManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        bridge = (Bridge) getActivity();
    }

    @Override
    public void onStart() {
        super.onStart();

        if (waitingDialog != null) {
            try {
                waitingDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (waitingDialog != null) {
            try {
                waitingDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        if (waitingDialog != null) {
            try {
                waitingDialog.dismiss();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initialize();
    }

    public abstract String getFragmentTag();

    public void initialize() {
    }

    public void loadDisplay() {
    }
}
