package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.Language;

import java.util.List;

import io.github.luizgrp.sectionedrecyclerviewadapter.Section;
import io.github.luizgrp.sectionedrecyclerviewadapter.SectionParameters;

public class LanguagesSection extends Section {

    private final String title;
    private final List<Language> list;
    private final ClickListener clickListener;

    public LanguagesSection(@NonNull final String title, @NonNull final List<Language> list,
                            @NonNull final ClickListener clickListener) {

        super(SectionParameters.builder()
                .itemResourceId(R.layout.adapter_lang)
                .headerResourceId(R.layout.adapter_lang_header)
                .build());

        this.title = title;
        this.list = list;
        this.clickListener = clickListener;
    }

    @Override
    public int getContentItemsTotal() {
        return list.size();
    }

    @Override
    public RecyclerView.ViewHolder getItemViewHolder(final View view) {
        return new LanguageItemViewHolder(view);
    }

    @Override
    public void onBindItemViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final LanguageItemViewHolder itemHolder = (LanguageItemViewHolder) holder;

        final Language language = list.get(position);

        itemHolder.checkImageView.setVisibility(language.isChecked() ? View.VISIBLE : View.INVISIBLE);
        itemHolder.nameTextView.setText(language.getName());
        itemHolder.orgNameTextView.setText(language.getOrgName());

        itemHolder.rootView.setOnClickListener(v ->
                clickListener.onItemRootViewClicked(title, itemHolder.getAdapterPosition())
        );
    }

    @Override
    public RecyclerView.ViewHolder getHeaderViewHolder(final View view) {
        return new LanguageHeaderViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final RecyclerView.ViewHolder holder) {
        final LanguageHeaderViewHolder headerHolder = (LanguageHeaderViewHolder) holder;

        headerHolder.headerTextView.setText(title);
    }

    public String getTitle() {
        return title;
    }

    public List<Language> getList() {
        return list;
    }

    public interface ClickListener {

        void onItemRootViewClicked(@NonNull final String sectionTitle, final int itemAdapterPosition);
    }
}
