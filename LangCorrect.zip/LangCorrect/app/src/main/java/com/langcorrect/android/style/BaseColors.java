package com.langcorrect.android.style;

import android.graphics.Color;

class BaseColors {
    static final int LC_WHITE = Color.parseColor("#FFFFFF");
    static final int LC_GRAY = Color.parseColor("#C3C3C3");
    static final int LC_BLACK = Color.BLACK;
    static final int LC_CLEAR = Color.TRANSPARENT;
    static final int LC_BLUE = Color.parseColor("#5E72E4");
}
