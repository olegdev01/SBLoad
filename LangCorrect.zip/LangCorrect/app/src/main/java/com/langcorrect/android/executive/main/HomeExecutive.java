package com.langcorrect.android.executive.main;

import com.langcorrect.android.executive.CommonExecutive;
import com.langcorrect.android.model.lang.LCEntry;
import com.langcorrect.android.model.lang.LCEntryType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HomeExecutive extends CommonExecutive {
    private HomeDisplay display;
    private Map<LCEntryType, HomePageDisplay> homePageDisplayMap = new HashMap<LCEntryType, HomePageDisplay>() {{
        put(LCEntryType.ALL, null);
        put(LCEntryType.FRIENDS, null);
        put(LCEntryType.OTHER, null);
    }};
    private Map<LCEntryType, ArrayList<LCEntry>> questionsMap = new HashMap<LCEntryType, ArrayList<LCEntry>>() {{
        put(LCEntryType.ALL, new ArrayList<>());
        put(LCEntryType.FRIENDS, new ArrayList<>());
        put(LCEntryType.OTHER, new ArrayList<>());
    }};


    public HomeExecutive(HomeDisplay display) {
        super(display);
        this.display = display;
    }

    public void displayDidLoad() {
        display.loadDisplay();
        loadEntries();
    }

    public void loadPageDisplay(LCEntryType entryType, HomePageDisplay homePageDisplay) {
        homePageDisplayMap.put(entryType, homePageDisplay);
        homePageDisplayMap.get(entryType).reloadPage(questionsMap.get(entryType));
    }

    public void loadEntries() {
        for (int index = 0; index < 10; index++) {
            LCEntry entry = new LCEntry("March 26, 2020, 5:15 a.m.",
                    "LangCorrect mobile app is in development!",
                    "Improve ashamed married expense bed her comfort pursuit mrs. Four time took ye your as fail lady. Up greatest am exertion or marianne. Shy occasional terminated insensible and inhabiting gay. So know do fond to half on. Now who promise was justice new winding. In finished on he speak...");
            questionsMap.get(LCEntryType.ALL).add(entry);
            questionsMap.get(LCEntryType.FRIENDS).add(entry);
            questionsMap.get(LCEntryType.OTHER).add(entry);
        }
        display.loadPages();
    }

    public interface HomeDisplay extends CommonDisplay {
        void loadDisplay();

        void loadPages();
    }

    public interface HomePageDisplay extends CommonDisplay {
        void reloadPage(ArrayList<LCEntry> entries);
    }
}
