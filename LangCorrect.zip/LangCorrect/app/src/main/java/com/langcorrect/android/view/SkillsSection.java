package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.Skill;

import java.util.List;

import io.github.luizgrp.sectionedrecyclerviewadapter.Section;
import io.github.luizgrp.sectionedrecyclerviewadapter.SectionParameters;

public class SkillsSection extends Section {

    private final String title;
    private final List<Skill> list;
    private final ClickListener clickListener;

    public SkillsSection(@NonNull final String title, @NonNull final List<Skill> list,
                         @NonNull final ClickListener clickListener) {

        super(SectionParameters.builder()
                .itemResourceId(R.layout.adapter_skill)
                .headerResourceId(R.layout.adapter_lang_header)
                .build());

        this.title = title;
        this.list = list;
        this.clickListener = clickListener;
    }

    @Override
    public int getContentItemsTotal() {
        return list.size();
    }

    @Override
    public RecyclerView.ViewHolder getItemViewHolder(final View view) {
        return new SkillItemViewHolder(view);
    }

    @Override
    public void onBindItemViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final SkillItemViewHolder itemHolder = (SkillItemViewHolder) holder;

        final Skill skill = list.get(position);

        itemHolder.checkImageView.setVisibility(skill.isChecked() ? View.VISIBLE : View.INVISIBLE);
        itemHolder.nameTextView.setText(skill.getSkillName());
        itemHolder.descTextView.setText(skill.getSkillDescription());
        itemHolder.ratingBar.setRating(skill.getLevel());

        itemHolder.rootView.setOnClickListener(v ->
                clickListener.onItemRootViewClicked(title, itemHolder.getAdapterPosition())
        );
    }

    @Override
    public RecyclerView.ViewHolder getHeaderViewHolder(final View view) {
        return new LanguageHeaderViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final RecyclerView.ViewHolder holder) {
        final LanguageHeaderViewHolder headerHolder = (LanguageHeaderViewHolder) holder;

        headerHolder.headerTextView.setText(title);
    }

    public String getTitle() {
        return title;
    }

    public List<Skill> getList() {
        return list;
    }

    public interface ClickListener {

        void onItemRootViewClicked(@NonNull final String sectionTitle, final int itemAdapterPosition);
    }
}