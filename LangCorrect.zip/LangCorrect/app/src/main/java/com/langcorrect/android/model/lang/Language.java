package com.langcorrect.android.model.lang;

public class Language {
    private int langId;
    private String name;
    private boolean checked;
    private String orgName;

    public Language(int langId, String name) {
        this.langId = langId;
        this.name = name;
        this.checked = false;
        this.orgName = "";
    }

    public int getLangId() {
        return langId;
    }

    public void setLangId(int langId) {
        this.langId = langId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
}
