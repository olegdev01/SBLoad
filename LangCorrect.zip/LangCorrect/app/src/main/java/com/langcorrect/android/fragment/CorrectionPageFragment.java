package com.langcorrect.android.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.LCCorrectionType;

public class CorrectionPageFragment extends BaseFragment {

    private String pageTitle;
    private LCCorrectionType correctionType;

    public CorrectionPageFragment() {

        correctionType = LCCorrectionType.INDIVIDUAL;
        pageTitle = "";
    }

    public static CorrectionPageFragment newInstance(Object... args) {
        CorrectionPageFragment fragment = new CorrectionPageFragment();

        if (args != null && args.length > 0) {
            fragment.correctionType = (LCCorrectionType) args[0];
        }

        if (args != null && args.length > 1) {
            fragment.pageTitle = (String) args[1];
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_correction_page, container, false);
        return view;
    }

    @Override
    public String getFragmentTag() {
        return CorrectionPageFragment.class.getCanonicalName();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public String getTitle() {
        return pageTitle;
    }
}
