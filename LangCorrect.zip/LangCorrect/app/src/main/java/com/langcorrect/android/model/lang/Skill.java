package com.langcorrect.android.model.lang;

public class Skill {
    private int skillId;
    private String skillCategory;
    private String skillName;
    private String skillDescription;
    private float level;
    private boolean checked;

    public Skill(String skillCategory, String skillName, String skillDescription, float level) {
        this.skillCategory = skillCategory;
        this.skillName = skillName;
        this.skillDescription = skillDescription;
        this.level = level;
        this.checked = false;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public String getSkillCategory() {
        return skillCategory;
    }

    public void setSkillCategory(String skillCategory) {
        this.skillCategory = skillCategory;
    }

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public String getSkillDescription() {
        return skillDescription;
    }

    public void setSkillDescription(String skillDescription) {
        this.skillDescription = skillDescription;
    }

    public float getLevel() {
        return level;
    }

    public void setLevel(float level) {
        this.level = level;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }
}