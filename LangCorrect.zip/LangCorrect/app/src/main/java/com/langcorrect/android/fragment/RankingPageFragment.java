package com.langcorrect.android.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.langcorrect.android.R;
import com.langcorrect.android.model.account.Ranking;
import com.langcorrect.android.model.account.RankingType;
import com.langcorrect.android.view.RankingAdapter;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class RankingPageFragment extends BaseFragment implements RankingAdapter.AdapterListener {

    private String pageTitle;
    private RankingType rankingType;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private RankingAdapter adapter;

    public RankingPageFragment() {
        pageTitle = "";
    }

    public static RankingPageFragment newInstance(Object... args) {
        RankingPageFragment fragment = new RankingPageFragment();

        if (args != null && args.length > 0) {
            fragment.rankingType = (RankingType) args[0];
        }

        if (args != null && args.length > 1) {
            fragment.pageTitle = (String) args[1];
        }
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_ranking_page, container, false);

        recyclerView = contentView.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new RankingAdapter(this, getActivity());
        recyclerView.setAdapter(adapter);

        return contentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {
            return;
        }

        ArrayList<Ranking> rankings = new ArrayList<>();
        ArrayList<String> authors = new ArrayList<>(Arrays.asList(
            "rom", "Bees", "jack_minnesota", "chou_fleur", "Manny", "jaicoholic", "amuntiavall", "chimsen", "sambal", "monsieur_elephant"
            , "Dmaster35", "baller377", "Cro the Goon", "PoorManGameSpot", "PoorManGameSpot", "chimsen", "sambal", "monsieur_elephant", "sambal", "chimsen"
            , "chou_fleur", "Bees", "jack_minnesota", "rom", "chou_fleur", "chimsen", "Manny", "jack_minnesota", "monsieur_elephant", "sambal"
        ));
        ArrayList<Integer> counts = new ArrayList<>(Arrays.asList(
                164, 158, 146, 133, 119, 85, 38, 21, 5, 5
                , 5, 5, 5, 5, 5, 4, 4, 4, 3, 3
                , 3, 3, 3, 2, 2, 2, 2, 1, 1, 1
        ));

        for (int index = 0; index < authors.size(); index++) {
            Ranking ranking = new Ranking(index + 1, authors.get(index), counts.get(index));
            rankings.add(ranking);
        }

        adapter.setRankingItems(rankings);
        adapter.notifyDataSetChanged();
    }

    @Override
    public String getFragmentTag() {
        return RankingPageFragment.class.getCanonicalName();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public String getTitle() {
        return pageTitle;
    }
}
