package com.langcorrect.android.style;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatEditText;

public class EditTextFieldBorder extends AppCompatEditText {
    GradientDrawable gradientDrawable;

    public EditTextFieldBorder(Context context, AttributeSet attrs) {
        super(context, attrs);
        gradientDrawable = new GradientDrawable();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        setTextColor(BaseColors.LC_GRAY);
        setHintTextColor(BaseColors.LC_GRAY);
        gradientDrawable.setCornerRadius(6.0f);
        gradientDrawable.setColor(BaseColors.LC_CLEAR);
        gradientDrawable.setStroke(2, BaseColors.LC_GRAY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            setBackground(gradientDrawable);
        } else {
            setBackgroundDrawable(gradientDrawable);
        }
    }
}
