package com.langcorrect.android.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.lang.LCEntry;

import java.util.ArrayList;
import java.util.List;

public class EntryAdapter extends RecyclerView.Adapter<EntryAdapter.ViewHolder> {

    private Context context;
    private List<LCEntry> dataSet;
    private AdapterListener adapterListener;
    private Integer gearPosition;

    public EntryAdapter(AdapterListener listener, Context context) {
        this.context = context;
        adapterListener = listener;
        dataSet = new ArrayList<>();
        gearPosition = -1;
    }

    public void add(LCEntry item) {
        dataSet.add(item);
    }

    public void setEntryItems(ArrayList<LCEntry> messageItems) {
        ArrayList<LCEntry> newMessageItems = new ArrayList<>();
        for (LCEntry messageItem : messageItems) {
            LCEntry newMessageItem = new LCEntry();
            newMessageItem.copy(messageItem);
            newMessageItems.add(newMessageItem);
        }

        dataSet = newMessageItems;
    }

    public void setGearPosition(Integer gearPosition) {
        this.gearPosition = gearPosition;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_entry, parent, false);
        return new ViewHolder(root, context);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final LCEntry message = dataSet.get(position);

        holder.setContent(message, gearPosition);
        holder.setEvent(message, position, gearPosition);
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface AdapterListener {
        void onGear(LCEntry message, Integer position, Integer gearPosition);

        void onDetail(LCEntry message, Integer position, Integer gearPosition);

        void onPrompt(LCEntry message, Integer position);

        void onEntry(LCEntry message, Integer position);
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        Context context;

        View rootView;
        AppCompatTextView userNameTextView, starsTextView, dateTimeTextView;
        AppCompatTextView titleTextView, contentTextView, correlationTextView;
        AppCompatTextView commentTextView, visitTextView, langTextView;
        AppCompatImageView gearButton;
        View gearLayout, btnPrompt, btnEntry;

        private ViewHolder(View root, Context context) {
            super(root);

            this.context = context;

            this.rootView = root;
            userNameTextView = root.findViewById(R.id.txt_username);
            starsTextView = root.findViewById(R.id.txt_stars);
            dateTimeTextView = root.findViewById(R.id.txt_date_time);
            titleTextView = root.findViewById(R.id.txt_title);
            contentTextView = root.findViewById(R.id.txt_content);
            correlationTextView = root.findViewById(R.id.txt_correlation);
            commentTextView = root.findViewById(R.id.txt_comment);
            visitTextView = root.findViewById(R.id.txt_visit);
            langTextView = root.findViewById(R.id.txt_lang);
            gearButton = root.findViewById(R.id.btn_gear);
            gearLayout = root.findViewById(R.id.layout_gear_buttons);
            btnPrompt = root.findViewById(R.id.btn_prompt);
            btnEntry = root.findViewById(R.id.btn_entry);
        }

        public void setContent(final LCEntry entry, Integer gearPosition) {
            userNameTextView.setText(entry.getUser().getUserName());
            starsTextView.setText(String.valueOf(entry.getUser().getStars()));
            dateTimeTextView.setText(entry.getDateTime());
            titleTextView.setText(entry.getTitle());
            contentTextView.setText(entry.getContent());
            correlationTextView.setText(String.valueOf(entry.getCorrelationCount()));
            commentTextView.setText(String.valueOf(entry.getCommentCount()));
            visitTextView.setText(String.valueOf(entry.getVisitCount()));
            if (gearPosition == getAdapterPosition()) {
                gearLayout.setVisibility(View.VISIBLE);
            } else {
                gearLayout.setVisibility(View.GONE);
            }
        }

        private void setEvent(final LCEntry entry, Integer position, Integer gearPosition) {
            rootView.setOnClickListener(view -> adapterListener.onDetail(entry, position, gearPosition));
            btnPrompt.setOnClickListener(view -> adapterListener.onPrompt(entry, position));
            btnEntry.setOnClickListener(view -> adapterListener.onEntry(entry, position));
            gearButton.setOnClickListener(v -> adapterListener.onGear(entry, position, gearPosition));
        }
    }
}
