package com.langcorrect.android.model.lang;

public enum LCEntryType {
    ALL("all"),
    FRIENDS("friends"),
    OTHER("other");

    public final String rawValue;

    LCEntryType(String rawValue) {
        this.rawValue = rawValue;
    }
}
