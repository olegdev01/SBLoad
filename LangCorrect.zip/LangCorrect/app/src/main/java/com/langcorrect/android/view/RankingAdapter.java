package com.langcorrect.android.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.langcorrect.android.model.account.Ranking;
import com.langcorrect.android.model.lang.LCEntry;

import java.util.ArrayList;
import java.util.List;

public class RankingAdapter extends RecyclerView.Adapter<RankingAdapter.ViewHolder> {

    private Context context;
    private List<Ranking> dataSet;
    private AdapterListener adapterListener;

    public RankingAdapter(AdapterListener listener, Context context) {
        this.context = context;
        adapterListener = listener;
        dataSet = new ArrayList<>();
    }

    public void add(Ranking item) {
        dataSet.add(item);
    }

    public void setRankingItems(ArrayList<Ranking> rankingItems) {
        this.dataSet.clear();

        ArrayList<Ranking> newRankingItems = new ArrayList<>();
        for (Ranking rankingItem : rankingItems) {
            Ranking newRankingItem = new Ranking();
            newRankingItem.copy(rankingItem);
            newRankingItems.add(newRankingItem);
        }

        dataSet = newRankingItems;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_ranking, parent, false);
        return new ViewHolder(root, context);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Ranking ranking = dataSet.get(position);

        holder.setContent(ranking, position);
        holder.setEvent(ranking, position);
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface AdapterListener {
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        Context context;

        View rootView;
        AppCompatTextView rankTextView, authorTextView, countTextView;

        private ViewHolder(View root, Context context) {
            super(root);

            this.context = context;

            this.rootView = root;
            rankTextView = root.findViewById(R.id.txt_rank);
            authorTextView = root.findViewById(R.id.txt_author);
            countTextView = root.findViewById(R.id.txt_count);
        }

        public void setContent(final Ranking ranking, Integer position) {
            if (position % 2 == 0) {
                rootView.setBackgroundResource(R.color.white);
            }
            else {
                rootView.setBackgroundResource(R.color.gray_color9);
            }
            rankTextView.setText(String.valueOf(ranking.getRanking()));
            authorTextView.setText(ranking.getUser().getUserName());
            countTextView.setText(String.valueOf(ranking.getCount()));
        }

        private void setEvent(final Ranking ranking, Integer position) {
        }
    }
}
