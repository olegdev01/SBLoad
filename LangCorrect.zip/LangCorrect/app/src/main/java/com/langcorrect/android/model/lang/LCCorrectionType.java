package com.langcorrect.android.model.lang;

public enum LCCorrectionType {
    INDIVIDUAL("individual"),
    GROUP("correction");

    public final String rawValue;

    LCCorrectionType(String rawValue) {
        this.rawValue = rawValue;
    }
}
