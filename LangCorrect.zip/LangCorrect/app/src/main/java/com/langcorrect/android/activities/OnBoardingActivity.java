package com.langcorrect.android.activities;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.langcorrect.android.R;

import java.util.ArrayList;
import java.util.List;

import me.relex.circleindicator.CircleIndicator;

public class OnBoardingActivity extends BaseActivity implements View.OnClickListener {

    private ViewPager viewPager;
    private OnBoardingPagerAdapter pagerAdapter;
    private CircleIndicator circleIndicator;
    private AppCompatTextView skipButton, nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_onboarding);

        initView();
    }

    private void initView() {
        viewPager = findViewById(R.id.pager);
        pagerAdapter = new OnBoardingPagerAdapter();
        viewPager.setAdapter(pagerAdapter);

        List<OnBoardingData> dataList = new ArrayList<>();
        dataList.add(new OnBoardingData(getString(R.string.onboarding_title_1), getString(R.string.onboarding_content_1), R.drawable.img_onboarding_1));
        dataList.add(new OnBoardingData(getString(R.string.onboarding_title_2), getString(R.string.onboarding_content_2), R.drawable.img_onboarding_2));
        dataList.add(new OnBoardingData(getString(R.string.onboarding_title_3), getString(R.string.onboarding_content_3), R.drawable.img_onboarding_3));
        dataList.add(new OnBoardingData(getString(R.string.onboarding_title_4), getString(R.string.onboarding_content_4), R.drawable.img_onboarding_3));

        pagerAdapter.setData(dataList);

        circleIndicator = findViewById(R.id.indicator);
        circleIndicator.setViewPager(viewPager);

        skipButton = findViewById(R.id.btn_skip);
        nextButton = findViewById(R.id.btn_next);
        skipButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float v, int i1) {

            }

            @Override
            public void onPageSelected(int position) {
                skipButton.setVisibility(position == 3 ? View.GONE : View.VISIBLE);
                nextButton.setText(position == 3 ? R.string.ok : R.string.next);
            }

            @Override
            public void onPageScrollStateChanged(int position) {

            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_skip:
                showActivity(RegisterActivity.class, ANIMATION_RIGHT_TO_LEFT, true);
                break;
            case R.id.btn_next:
                int position = viewPager.getCurrentItem();
                if (position < 3) {
                    viewPager.setCurrentItem(position + 1);
                } else {
                    showActivity(RegisterActivity.class, ANIMATION_RIGHT_TO_LEFT, true);
                }
                break;
        }
    }

    /**
     * Pager Model
     **/
    private class OnBoardingData {
        String title;
        String content;
        int resourceId;

        OnBoardingData(String title, String content, int resourceId) {
            this.title = title;
            this.content = content;
            this.resourceId = resourceId;
        }

        String getTitle() {
            return title;
        }

        public String getContent() {
            return content;
        }

        int getResourceId() {
            return resourceId;
        }
    }

    /**
     * Pager Adapter
     **/
    private class OnBoardingPagerAdapter extends PagerAdapter {
        private List<OnBoardingData> dataList = new ArrayList<>();

        @Override
        public int getCount() {
            return dataList.size();
        }

        void setData(List<OnBoardingData> _dataList) {
            dataList.clear();
            dataList.addAll(_dataList);
            notifyDataSetChanged();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        public int getItemPosition(@NonNull Object object) {
            return POSITION_NONE;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }

        @Override
        public @NonNull
        Object instantiateItem(@NonNull ViewGroup container, int position) {
            View view = getLayoutInflater().inflate(R.layout.view_onboarding_item, container, false);

            OnBoardingData data = dataList.get(position);

            ImageView imgOnBoarding = view.findViewById(R.id.imgOnBoarding);
            TextView txtTitle = view.findViewById(R.id.txtTitle);
            TextView txtContent = view.findViewById(R.id.txtContent);

            imgOnBoarding.setImageResource(data.getResourceId());
            txtTitle.setText(data.getTitle());
            txtContent.setText(data.getContent());

            // add viewpager_item.xml to ViewPager
            container.addView(view);

            return view;
        }
    }
}
