package com.langcorrect.android.style;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

public class TextViewRoundedBlue extends AppCompatTextView {
    GradientDrawable gradientDrawable;

    public TextViewRoundedBlue(Context context, AttributeSet attrs) {
        super(context, attrs);
        gradientDrawable = new GradientDrawable();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        setTextColor(BaseColors.LC_WHITE);
        gradientDrawable.setCornerRadius(6.0f);
        gradientDrawable.setColor(BaseColors.LC_BLUE);
        gradientDrawable.setStroke(2, BaseColors.LC_BLUE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            setBackground(gradientDrawable);
        } else {
            setBackgroundDrawable(gradientDrawable);
        }
    }
}