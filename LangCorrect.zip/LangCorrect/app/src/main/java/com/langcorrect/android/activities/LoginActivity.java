package com.langcorrect.android.activities;

import android.os.Bundle;
import android.view.View;

import com.langcorrect.android.R;
import com.langcorrect.android.activities.entry.MainActivity;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
    }

    private void initView() {
        findViewById(R.id.btn_login).setOnClickListener(this);
        findViewById(R.id.btn_forgot_password).setOnClickListener(this);
        findViewById(R.id.btn_register_account).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                showActivity(MainActivity.class, ANIMATION_RIGHT_TO_LEFT, true);
                break;
            case R.id.btn_forgot_password:
                showActivity(ForgotPasswordActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_register_account:
                showActivity(RegisterActivity.class, ANIMATION_RIGHT_TO_LEFT, true);
                break;
        }
    }
}
