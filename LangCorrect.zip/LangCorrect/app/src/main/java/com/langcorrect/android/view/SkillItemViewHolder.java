package com.langcorrect.android.view;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.langcorrect.android.R;
import com.willy.ratingbar.BaseRatingBar;

class SkillItemViewHolder extends RecyclerView.ViewHolder {

    final View rootView;
    final AppCompatImageView checkImageView;
    final AppCompatTextView nameTextView, descTextView;
    final BaseRatingBar ratingBar;

    SkillItemViewHolder(@NonNull View view) {
        super(view);

        rootView = view;
        checkImageView = view.findViewById(R.id.img_check);
        nameTextView = view.findViewById(R.id.txt_name);
        descTextView = view.findViewById(R.id.txt_desc);
        ratingBar = view.findViewById(R.id.rb_level);
    }
}
