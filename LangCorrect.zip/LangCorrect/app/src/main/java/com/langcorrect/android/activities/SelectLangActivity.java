package com.langcorrect.android.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.langcorrect.android.R;
import com.langcorrect.android.common.Constants;

public class SelectLangActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_lang);

        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_native_language).setOnClickListener(this);
        findViewById(R.id.btn_studying_language1).setOnClickListener(this);
        findViewById(R.id.btn_studying_language2).setOnClickListener(this);
        findViewById(R.id.btn_login).setOnClickListener(this);
        findViewById(R.id.btn_next).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                showActivity(LoginActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_next:
//                showActivity(MainActivity.class, ANIMATION_RIGHT_TO_LEFT, false);
                break;
            case R.id.btn_native_language:
                showActivityForResult(LangListActivity.class, Constants.LANG_TYPE_KEY,
                        Constants.LANG_NATIVE, Constants.REQUEST_SELECT_LANG);
                break;
            case R.id.btn_studying_language1:
                showActivityForResult(LangListActivity.class, Constants.LANG_TYPE_KEY,
                        Constants.LANG_STUDY1, Constants.REQUEST_SELECT_LANG);
                break;
            case R.id.btn_studying_language2:
                showActivityForResult(LangListActivity.class, Constants.LANG_TYPE_KEY,
                        Constants.LANG_STUDY2, Constants.REQUEST_SELECT_LANG);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.REQUEST_SELECT_LANG) {
            if (resultCode != Activity.RESULT_OK) {
            }

        }
    }
}
